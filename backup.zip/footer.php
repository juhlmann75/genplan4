<!-- Footer -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-md-12" style="font-size:8pt;text-align:left;">
          <p>
           Synergos Advisory LLC doing business as Synergos Advisory is a registered investment adviser in the state of Washington. 
		   The adviser may not transact business in states where it is not appropriately registered or exempt from registration. I
		   ndividualized responses to persons that involve either the effecting of transactions in securities or the rendering of 
		   personalized investment advice for compensation will not be made without registration or exemption.</p>
            <ul>
                <li><a href="files/Privacy_Policy.pdf" target="_blank">Privacy Policy & Disclaimer</a></li>
                <li><a href="files/ADV_Part_2A_2B.pdf" target="_blank">Form ADV Part 2A</a></li>
            </ul>
            <span style="float:right" id="siteseal"><script async type="text/javascript" src="https://seal.godaddy.com/getSeal?sealID=oT9MYY6AC4YK2fMliNjQIwTmcc8wSBBiuQsnId9kqsWzBOhUuNJxEY1RGvpV"></script></span>
            <center>Synergos Advisory LLC Copyright &copy; 2019</center>
        </div>
      </div>
    </div>
  </footer>